
import React from "react"
function Logo() {
    return (
        <div>
             <img src="https://i.imgur.com/Zmuzg62.gif" width = '20' /> 
            
        </div>
    )
}



export default Logo