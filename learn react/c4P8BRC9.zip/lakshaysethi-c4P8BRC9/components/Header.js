import React from "react"
import Logo from "../Images/Logo"
function Header(){
    return (
        <div>
            <header>
            
                 
                <Logo />
                <h1>Header</h1>
            </header>
        
        </div>
    )
}


export default Header