import React from "react"

function Main() {
    return (
        <div>
 
           <main>
                <p>This is where most of my content will go...</p>
            </main>
                       
          
        </div>
    )
}

export default Main